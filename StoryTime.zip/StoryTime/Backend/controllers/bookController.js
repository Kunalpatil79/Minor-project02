const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  genre: String,
  price: Number,
  description: String,
  coverImage: String, // base64 string or image URL
}, { timestamps: true });

module.exports = mongoose.model('Book', bookSchema);
