// Placeholder for admin check (not implemented in frontend yet)
module.exports = function (req, res, next) {
  // Add real logic later (e.g., JWT token check)
  next();
};
