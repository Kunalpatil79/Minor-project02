const express = require('express');
const router = express.Router();
const stripe = require('stripe')('sk_test_51RQ5HdPVTOJmxcB6r4xOfG9JUvpZ9GIajAqFv0FyO5CzqzyapTNI6CbbPDIRWtahmnpvV1NIcxQQH13jGyGbahdq008vtZadtx');
router.post('/create-checkout-session', async (req, res) => {
  const { cart, user } = req.body;

  console.log('Received cart:', cart);
  console.log('Received user:', user);

  if (!Array.isArray(cart) || cart.length === 0) {
    return res.status(400).json({ error: 'Cart is empty or invalid' });
  }

  if (!user || !user.email || !user.firstName || !user.lastName) {
    return res.status(400).json({ error: 'User information is incomplete' });
  }

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      customer_email: user.email,
      line_items: cart.map(item => ({
        price_data: {
          currency: 'usd',
          product_data: {
            name: item.title || 'Untitled Book',
          },
          unit_amount: Math.round(item.price * 100) || 1000, // fallback to $10
        },
        quantity: item.quantity || 1,
      })),
      mode: 'payment',
      success_url: 'http://localhost:3000/success.html',
      cancel_url: 'http://localhost:3000/checkout.html',
      metadata: {
        customer_name: `${user.firstName} ${user.lastName}`,
        address: `${user.address}, ${user.city}, ${user.country} ${user.postalCode}`
      }
    });

    res.json({ url: session.url });
  } catch (error) {
    console.error('Stripe error:', error.message);
    res.status(500).json({ error: 'Failed to create Stripe session', details: error.message });
  }
});
module.exports = router;