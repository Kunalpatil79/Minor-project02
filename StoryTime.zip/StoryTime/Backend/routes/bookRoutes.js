const express = require('express');
const router = express.Router();
const Book = require('../models/book');
const upload = require('../middleware/upload');

// Upload a new book
router.post('/', upload.single('coverImage'), async (req, res) => {
  try {
    const { title, author, price, description } = req.body;
    const newBook = new Book({
      title,
      author,
      price,
      description,
      coverImage: `/uploads/${req.file.filename}` // store image path
    });

    const savedBook = await newBook.save();
    res.status(201).json(savedBook);
  } catch (error) {
    res.status(500).json({ message: 'Book upload failed', error });
  }
});

// Get all books
router.get('/', async (req, res) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch books', err });
  }
});

module.exports = router; // ✅ This was missing
router.get('/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.json(book);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching book', error: err });
  }
});
