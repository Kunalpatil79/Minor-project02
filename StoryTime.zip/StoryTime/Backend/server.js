const mongoose = require('mongoose');
const app = require('./app');
require('dotenv').config(); // If you're using a .env file

const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/BookStore';

// Connect to MongoDB
mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('✅ Connected to MongoDB');
    app.listen(PORT, () => {
      console.log(`🚀 Server is running at http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error('❌ MongoDB connection failed:', err);
  });
const checkoutRoutes = require("./routes/checkout");
app.use('/api/checkout',checkoutRoutes);