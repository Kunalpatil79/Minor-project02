async function fetchAndRenderBooks() {
  try {
    const res = await fetch('http://localhost:3000/api/books');
    const books = await res.json();
    const container = document.getElementById('book-list');
    container.innerHTML = '';

    if (books.length === 0) {
      container.innerHTML = '<p class="text-center text-gray-500">No books found.</p>';
      return;
    }

    books.forEach(book => {
      const bookCard = document.createElement('div');
      bookCard.className =
        "bg-white p-4 rounded-lg shadow hover:shadow-lg transition w-full max-w-xs";

      bookCard.innerHTML = `
        <a href="product.html?id=${book._id}">
          <img src="http://localhost:3000${book.coverImage}" 
               alt="${book.title}" 
               class="w-full h-64 object-cover rounded mb-4" />

          <h3 class="text-lg font-bold mb-1">${book.title}</h3>
          <p class="text-sm text-gray-600">${book.author}</p>
          <p class="text-md font-semibold text-amber-700 mt-2 mb-4">$${parseFloat(book.price).toFixed(2)}</p>
        </a>

        <button onclick="addToCart('${book._id}')"
                class="w-full bg-amber-700 text-white font-semibold px-4 py-2 rounded hover:bg-amber-800 transition">
          Add to Cart
        </button>
      `;

      container.appendChild(bookCard);
    });
  } catch (error) {
    console.error('Failed to load books:', error);
    document.getElementById('book-list').innerHTML =
      '<p class="text-center text-red-500">Failed to load books. Please try again later.</p>';
  }
}

// Call on page load
window.addEventListener('load', fetchAndRenderBooks);
