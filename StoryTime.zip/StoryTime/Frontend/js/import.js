// frontend/js/import.js

document.addEventListener('DOMContentLoaded', () => {
  const loadFragment = async (url, containerId) => {
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Failed to load ${url}: ${response.status}`);
      const html = await response.text();
      document.getElementById(containerId).innerHTML = html;
    } catch (err) {
      console.error(err);
    }
  };

  // Since import.js lives in js/, we go up one level to pages/
  loadFragment('../pages/header.html', 'header');
  loadFragment('../pages/footer.html', 'footer');
});
