// Add to Cart
function addToCart(bookId) {
  fetch(`http://localhost:3000/api/books/${bookId}`)
    .then(res => res.json())
    .then(book => {
      const cart = JSON.parse(localStorage.getItem('cart')) || [];

      const existing = cart.find(item => item._id === book._id);
      if (existing) {
        existing.quantity += 1;
      } else {
        cart.push({ ...book, quantity: 1 });
      }

      localStorage.setItem('cart', JSON.stringify(cart));
      alert(`✅ "${book.title}" added to cart`);
      updateCartIcon();
    })
    .catch(err => {
      console.error('Error adding to cart:', err);
      alert('❌ Failed to add book to cart');
    });
}

// Update cart icon count
function updateCartIcon() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartBadge = document.getElementById('cart-count');
  if (cartBadge) cartBadge.textContent = totalItems;
}

// Render cart on cart.html
function renderCart() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const container = document.getElementById('cart-items');
  const totalElement = document.getElementById('cart-total');
  container.innerHTML = '';

  if (cart.length === 0) {
    container.innerHTML = '<p class="text-center text-gray-500">Your cart is empty.</p>';
    totalElement.textContent = '$0.00';
    return;
  }

  let total = 0;

  cart.forEach((book, index) => {
    const title = book.title || 'Untitled';
    const author = book.author || 'Unknown';
    const price = parseFloat(book.price) || 0;
    const quantity = parseInt(book.quantity) || 1;
    const itemTotal = price * quantity;

    total += itemTotal;

    const item = document.createElement('div');
item.className = 'grid grid-cols-12 gap-4 items-center border-b py-4 cart-item';

item.innerHTML = `
  <div class="col-span-2">
    <img src="http://localhost:3000${book.coverImage}" alt="${title}" class="w-16 h-24 object-cover rounded shadow" />
  </div>
  <div class="col-span-3">
    <h3 class="font-bold">${title}</h3>
    <p class="text-sm text-gray-600">${author}</p>
  </div>
  <div class="col-span-2 text-center">$${price.toFixed(2)}</div>
  <div class="col-span-2 text-center">
    <input type="number" min="1" value="${quantity}" data-index="${index}" class="qty-input w-16 text-center border rounded" />
  </div>
  <div class="col-span-2 text-center">$${itemTotal.toFixed(2)}</div>
  <div class="col-span-1 text-right">
    <button onclick="removeFromCart(${index})" class="text-red-500 hover:underline">Remove</button>
  </div>
`;


    container.appendChild(item);
  });

  totalElement.textContent = `$${total.toFixed(2)}`;
}

// Remove item from cart
function removeFromCart(index) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  renderCart();
  updateCartIcon();
}

// Update quantity on input change
document.addEventListener('input', (e) => {
  if (e.target.classList.contains('qty-input')) {
    const index = parseInt(e.target.dataset.index);
    const newQty = parseInt(e.target.value);

    if (newQty < 1 || isNaN(newQty)) return;

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart[index]) {
      cart[index].quantity = newQty;
      localStorage.setItem('cart', JSON.stringify(cart));
      renderCart();
    }
  }
});

// Load when page is ready
window.addEventListener('load', () => {
  if (document.getElementById('cart-items')) {
    renderCart();
  }
  updateCartIcon();
});
