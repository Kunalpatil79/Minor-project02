document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const bookId = params.get('id');
  const loader = document.getElementById('product-loader');
  const detail = document.getElementById('product-detail');

  if (!bookId) {
    loader.textContent = '❌ Book ID not found in URL.';
    return;
  }

  fetch(`http://localhost:3000/api/books/${bookId}`)
    .then(res => res.json())
    .then(book => {
      document.getElementById('product-title').textContent = book.title || 'Untitled';
      document.getElementById('product-author').textContent = `by ${book.author || 'Unknown'}`;
      document.getElementById('product-description').textContent = book.description || '';
      document.getElementById('product-price').textContent = parseFloat(book.price).toFixed(2);
      document.getElementById('product-image').src = `http://localhost:3000${book.coverImage}`;

      loader.classList.add('hidden');
      detail.classList.remove('hidden');

      // Add to Cart Logic
      document.getElementById('add-to-cart')?.addEventListener('click', () => {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        const existing = cart.find(item => item._id === book._id);

        if (existing) {
          existing.quantity += 1;
        } else {
          cart.push({ ...book, quantity: 1 });
        }

        localStorage.setItem('cart', JSON.stringify(cart));
        alert(`✅ "${book.title}" added to cart`);
        updateCartIcon?.();
      });
    })
    .catch(err => {
      console.error(err);
      loader.textContent = '❌ Failed to load book details.';
    });
});
